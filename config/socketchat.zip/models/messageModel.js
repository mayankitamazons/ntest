const mongoose = require("mongoose");

const MessageSchema = mongoose.Schema(
  {
    // message: {
    //   text: { type: String, required: true },
    // },
    users: Array,
    message: { type: String, required: true },
    sender: { type: String, required: true },
    reciver: { type: String, required: true },
    trip_id: { type: String, required: true },
    // sender: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "User",
    //   required: true,
    // },
    created_at: {
      type: Date,
      default: Date.now,
    },
    showmsg: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("Messages", MessageSchema);
