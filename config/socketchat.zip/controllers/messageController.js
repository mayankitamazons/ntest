const Messages = require("../models/messageModel");
const COMMON = require("../shared/common");
const Query = require("../lib/query");
module.exports.getMessages = async (req, res, next) => {
  try {
    const { from, to, trip_id } = req.body;
    console.log("get msg req body", req.body);
    const messages = await Messages.find({
      trip_id: trip_id,
      showmsg: true,
      $or: [
        { sender: from, reciver: to },
        { sender: to, reciver: from },
      ],
      //  users: {
      //   $all: [from, to],
      // },
    }).sort({ updatedAt: 1 });
    // console.log("message", messages);
    if (messages.length > 0) {
      const projectedMessages = messages.map((msg) => {
        return {
          fromSelf: msg.sender.toString() === from,
          message: msg.message,
          created_at: msg.created_at,
          trip_id: msg.trip_id,
        };
      });

      return res.json({
        msg: "Message List",
        status: true,
        data: projectedMessages,
      });
    } else {
      return res.json({
        msg: "No Message Found",
        status: false,
        data: [],
      });
    }

    // res.json(projectedMessages);
  } catch (ex) {
    // next(ex);
    return res.json({
      msg: "No Message Found",
      status: false,
      data: [],
    });
  }
};

module.exports.addMessage = async (req, res, next) => {
  // console.log('add msg request',req.b);
  try {
    console.log("add msg req body", req.body);
    var { from, to, message, trip_id, to_notification_id, chat_id } = req.body;
    const blockedmsgarray = ["cash", "payment"];
    var showmsg = true;
    var matchmessage = message.replace(/\s+/g, "");
    if (blockedmsgarray.includes(matchmessage.toLowerCase())) {
      showmsg = false;
    }
    if (showmsg) {
      const regex = /^(\+?\d{1,3}[- ]?)?\d{10}$/;
      var mobilecheck = regex.test(message);
      console.log("mobile check ", mobilecheck);
      if (mobilecheck) showmsg = false;
    }
    const data = await Messages.create({
      message: message,
      users: [from, to],
      trip_id: trip_id,
      sender: from,
      reciver: to,
      showmsg: showmsg,
    });

    if (data) {
      // update msg flag
      if (chat_id) {
        var updatechat = Query.query(
          "UPDATE `chats` SET `is_unread` = '1' where id=" + chat_id
        );
        // console.log("updatechat", updatechat);
      }

      const messagesdata = await Messages.find({
        trip_id: trip_id,
      }).sort({ updatedAt: 1 });
      // console.log("message data", messagesdata);
      var projectedMessages = [];
      if (messagesdata.length > 0) {
        var projectedMessages = messagesdata.map((msg) => {
          return {
            fromSelf: msg.sender.toString() === from,
            message: msg.message,
            created_at: msg.created_at,
            trip_id: msg.trip_id,
          };
        });
      }
      if (showmsg === false) {
        return res
          .status(401)
          .json({ message: "Blocked Message", status: 201 });
      } else {
        var payload = {
          trip_id: trip_id,
          from: from,
          to: to,
          type: "newmsg",
          chat: projectedMessages,
        };
        if (to_notification_id) {
          COMMON.sendNotification(
            message,
            "New message",
            to_notification_id,
            payload
          );
        }

        return res.json({ msg: "Message added successfully." });
      }
    } else {
      return res.json({ msg: "Failed to add message to the database" });
    }
  } catch (ex) {
    next(ex);
  }
};
