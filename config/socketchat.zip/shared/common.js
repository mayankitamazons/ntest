module.exports = {
  sendNotification: async function (
      text,
      title,
      notification_id,
      payload = null
    ) {
      const OneSignal = require("onesignal-node"); // One signal library
      // One signal client setup with appId and API Key
      const client = new OneSignal.Client(
        // process.env.ONESINGAL_ACCOUNT_SID,
        // process.env.ONESINGAL_AUTH_TOKEN
        "94d98edd-ee71-477d-858b-f23545df72a3","ZGQwZGQzYWEtOTkyNi00ZmQzLWJlNmYtNmZkZTJmZjk4YzMz"
       
      );  
     
      var notification = {
        contents: {
          en: text,
        },
        headings: {
          en: title,
        },
        // included_segments: ['Subscribed Users']
        include_player_ids:[notification_id]
      };
      if (payload !== null) {
        notification.data = payload;
      }
  
      // using async/await
      try {
        const response = await client.createNotification(notification);
        // console.log('notification response',response);
        return { status: true, content: response };
      } catch (e) {
        return { status: false, content: e };
      }
    },
  };
  
