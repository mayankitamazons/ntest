let {
  GraphQLID,
  GraphQLString,
  GraphQLFloat,
  GraphQLInt,
  GraphQLObjectType,
  GraphQLNonNull,
  GraphQLList,
  GraphQLEnumType,
  GraphQLJSON,
  GraphQLBoolean,
} = require("graphql");
// const Commonlib = require("../../lib/commonlib");
const Query = require("../../lib/query");
var qna_schema = new GraphQLObjectType({
  name: "HelpQna",
  description: "HelpQna",
  fields: () => ({
    id: { type: GraphQLID },
    parent_id: { type: GraphQLInt },
    question: { type: GraphQLString },
    answer: { type: GraphQLString },
    clikable_slug: { type: GraphQLString },
    parent_id: { type: GraphQLInt },
  }),
});
const common_fields = {
  id: {
    type: GraphQLID,
  },
  title: {
    type: GraphQLString,
  },
  short_desc: { type: GraphQLString },
  icon: {
    type: GraphQLString,
  },
  slug: {
    type: GraphQLString,
  },
  qna: {
    type: GraphQLList(qna_schema),
    resolve: async (parent, args) => {
      if (!args.limit) var page_limit = 100000;
      else var page_limit = args.limit;
      if (!args.order) var page_order = "ASC";
      else var page_order = args.order;
      var search = { help_menu_id: parent.id, status: "1" };
      var p_order = { by: "display_order_no", direction: page_order };
      const qnalist = await Query.findByFields(
        "help_question_answers",
        search,
        page_limit,
        p_order
      );
      //console.log(result);
      return qnalist;
    },
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var c_schema = new GraphQLObjectType({
  name: "HelpMenu",
  description: "HelpMenu",
  fields: common_fields,
});

module.exports = {
  schema: c_schema,
  common_fields: common_fields,
};
