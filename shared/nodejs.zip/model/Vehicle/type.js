let {
  GraphQLID,
  GraphQLString,
  GraphQLInt,
  GraphQLObjectType,
  GraphQLNonNull,
  GraphQLBoolean,
} = require('graphql');

var auth_data = {
  userId: {
    type: GraphQLString,
  },
  token: {
    type: GraphQLString,
  },
  tokenExpiration: {
    type: GraphQLInt,
  },
};
const common_fields = {
  id: { type: GraphQLID },
  driver_id: { type: GraphQLInt },
  vehicle_type: { type: GraphQLString },
  photo: { type: GraphQLString },
  color: { type: GraphQLString },
  model_year: { type: GraphQLString },
  luggage_status: { type: GraphQLString },
  backrow_seating_status: { type: GraphQLString },
  others: { type: GraphQLString },
  registration_number: { type: GraphQLString },
  model: { type: GraphQLString },
  total_seat: { type: GraphQLInt },
  fuel_type: { type: GraphQLString },
  ac: { type: GraphQLString },
  status: { type: GraphQLString },
 
};
const c_schema = new GraphQLObjectType({
  name: 'Vehicle',
  description: 'Vehicle Master',
  fields: common_fields,
});

module.exports = {
  schema: c_schema,
  auth_data: auth_data,
  common_fields: common_fields,
};
