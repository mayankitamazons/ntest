const jwt = require("jsonwebtoken");
const moment = require("moment");
const Query = require("../../lib/query");
const bcrypt = require("bcrypt");
const { createJwtToken } = require("../../util/auth");
const { errorName } = require("../../middleware/errorContant");
const COMMON = require("../../shared/common");
exports.getchatlist = async function (args) {
  var q =
    "SELECT *,'User name , inquiry' as chat_title,'Orillia to Torento on Thu,Feb 28' as chat_sub_title,'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXg_uDJgZD3I925jo56-6gcLu3Q9BIk1uvM9dvGMk&s' as profile_pic FROM `chats` WHERE 1=1";
  var Chatresult = await Query.queryForList(q);
  if (Chatresult.length > 0) {
    return { list: Chatresult, statusCode: 200, message: "Trip List" };
  } else {
    return {
      list: [],
      statusCode: 200,
      message: "No Chat Found",
    };
  }
};
exports.createchat = async function (args) {
  let insertresult = await Query.insert("chats", {
    data: args,
  });
  if (insertresult.affectedRows > 0) {
    return {
      statusCode: 200,
      message: "Trip Chat created",
      chat_id: insertresult.insertId,
    };
  } else {
    var err = new Error(errorName.WENT_WRONG);
    throw err;
  }
};
