const Commonlib = require("../../lib/query");
const mySQLWrapper = require("../../lib/mysqlWrapper");

const generateUniqueId = require("generate-unique-id");

const jwt = require("jsonwebtoken");
const moment = require("moment");
require("dotenv").config();
class Issue {
  static async getIssueSubject() {
    return;
  }
  static async getIssueSubSubject(fields) {
    var baseQuery =
      "SELECT id,issue_reason_id,subject,status from issue_sub_reason where status='1' and issue_reason_id=" +
      fields.issue_reason_id +
      " order by id";
    var issue_sub_subject_list = await mySQLWrapper.createQuery({
      query: baseQuery,
    });

    if (issue_sub_subject_list) {
      return {
        list: issue_sub_subject_list,
        statusCode: 200,
        message: "Issue Sub Subject List",
      };
    } else {
      const error = new Error("No sub reason found");
      error.code = 404;
      throw error;
    }
  }
  static async submitIssue(fields) {
    if (fields.issue_sub_subject_id) {
    } else {
      fields.issue_sub_subject_id = null;
    }
    fields.user_type = "1";
    fields.raise_by = "1";
    let data = {
      booking_id: fields.booking_id,
      user_id: fields.user_id,
      message: fields.message,
      issue_subject_id: fields.issue_subject_id,
      issue_sub_subject_id: fields.issue_sub_subject_id,
      message_by: "0",
    };

    let result = await Commonlib.insert("issues", {
      data: data,
    });
    if (result.affectedRows > 0) {
      var issue_id = result.insertId;
      if (fields.image) {
        var query =
          "insert into issue_documents (issue_id,document) values (" +
          issue_id +
          ",'" +
          fields.image +
          "')";
        console.log(query);
        var insert = await mySQLWrapper.createQuery({
          query: query,
        });
      }
      return {
        issue_id: issue_id,
        statusCode: 200,
        message: "Issue Submit Successful",
      };
    } else {
      const error = new Error("Something Went Wrong 1");
      error.code = 404;
      throw error;
    }
  }
  static async getIssueChat(fields) {
    var baseQuery =
      "(SELECT issues.id,issues.booking_id,issues.user_id,issues.message,( CASE WHEN issues.message_by = '0' THEN 'Right'  WHEN issues.message_by = '1' THEN 'Left' ELSE '' END) AS messageBy,issue_documents.document,issues.reply_expected,issues.created from issues LEFT JOIN issue_documents on issue_documents.issue_id = issues.id where issues.id=" +
      fields.issue_id +
      " order by issues.id ) UNION ALL (SELECT issues.id,issues.booking_id,issues.user_id,issues.message,( CASE WHEN issues.message_by = '0' THEN 'Right'  WHEN issues.message_by = '1' THEN 'Left' ELSE '' END) AS messageBy,issue_documents.document,issues.reply_expected,issues.created from issues LEFT JOIN issue_documents on issue_documents.issue_id = issues.id where issues.parent_id=" +
      fields.issue_id +
      " order by issues.id)";
    console.log("query", baseQuery);
    var issue_list = await mySQLWrapper.createQuery({
      query: baseQuery,
    });

    if (issue_list) {
      return { list: issue_list, statusCode: 200, message: "Issue chat List" };
    } else {
      const error = new Error("No chat found");
      error.code = 404;
      throw error;
    }
  }
  static async submitIssueChat(fields) {
    let issue_detail = await Commonlib.findByFields("issues", {
      id: fields.issue_id,
    });
    if (issue_detail.length > 0) {
      let data = {
        user_id: fields.user_id,
        message: fields.message,
        message_by: "0",
        parent_id: fields.issue_id,
      };

      let result = await Commonlib.insert("issues", {
        data: data,
      });
      if (result) {
        return {
          issue_id: fields.issue_id,
          statusCode: 200,
          message: "Message send",
        };
      } else {
        const error = new Error("Something Went Wrong ");
        error.code = 404;
        throw error;
      }
    } else {
      const error = new Error("Something Went Wrong 1");
      error.code = 404;
      throw error;
    }
  }
}
module.exports = Issue;
