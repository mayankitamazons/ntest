const nodemailer = require('nodemailer');
var fs = require('fs');
var handlebars = require('handlebars');
// let transport = nodemailer.createTransport({
//     host: 'smtp.mailtrap.io',
//     port: 2525,
//     auth: {
//         user: '1b2c153084cd20',
//         pass: 'd9b5e5ad9f437e'
//     }
// });
let transport = nodemailer.createTransport({
    host: 'live.smtp.mailtrap.io',
    port: 587,
    auth: {
        user: 'api',
        pass: '1de9c84038bb5518a5ee8bb9c577148f'
    }
});

var readHTMLFile = function(path, callback) {
    fs.readFile(path, {encoding: 'utf-8'}, function (err, html) {
        if (err) {
           callback(err);                 
        }
        else {
            callback(null, html);
        }
    });
};


module.exports = {
	//done
	sendEmailAfterRegistration(toEmail,first_name) {
		// console.log('inside email send',toEmail);
		try {
			readHTMLFile(__dirname +'/template/RegistrationTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name
				 };
				 var htmlToSend = template(replacements);
				const token=123;
			var mailOptions = {
                to: toEmail,
                from: 'noreply@humbleride.ca',
                subject: 'Welcome to Humble Ride '+first_name,
				html : htmlToSend
            };
			transport.sendMail(mailOptions, function(err, info) {
				if (err) {
					console.log(err)
				} else {
					// return emailResponse;
					console.log(info);
				}
			});
			
			
			return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendVerificationEmail(toEmail,first_name) {
		// console.log('inside email send',toEmail);
		try {
			readHTMLFile(__dirname +'/template/VerificationEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name
				 };
				 var htmlToSend = template(replacements);
				const token=123;
			var mailOptions = {
                to: toEmail,
                from: 'noreply@humbleride.ca',
                subject: 'Verification email from Humble Ride',
				html : htmlToSend
            };
			transport.sendMail(mailOptions, function(err, info) {
				if (err) {
					console.log(err)
				} else {
					// return emailResponse;
					console.log(info);
				}
			});
			
			
			return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendOfferRideEmail(toEmail,first_name) {
		// console.log('inside email send',toEmail);
		try {
			readHTMLFile(__dirname +'/template/OfferRideEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name
				 };
				 var htmlToSend = template(replacements);
				const token=123;
			var mailOptions = {
                to: toEmail,
                from: 'noreply@humbleride.ca',
                subject: 'Ride offer posted',
				html : htmlToSend
            };
			transport.sendMail(mailOptions, function(err, info) {
				if (err) {
					console.log(err)
				} else {
					// return emailResponse;
					console.log(info);
				}
			});
			
			
			return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendFindRideEmail(toEmail,first_name) {
		// console.log('inside email send',toEmail);
		try {
			readHTMLFile(__dirname +'/template/FindRideEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name
				 };
				 var htmlToSend = template(replacements);
				const token=123;
			var mailOptions = {
                to: toEmail,
                from: 'noreply@humbleride.ca',
                subject: 'Ride offer posted',
				html : htmlToSend
            };
			transport.sendMail(mailOptions, function(err, info) {
				if (err) {
					console.log(err)
				} else {
					// return emailResponse;
					console.log(info);
				}
			});
			
			
			return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendRequestFromPassangerEmail(toEmail,first_name,customer_name,from,to,trip_date_time,exp_time,customer_msg){
		try {
			readHTMLFile(__dirname +'/template/RequestFromPassangerEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  customer_name:customer_name,
					  from:from,
					  to:to,
					  trip_date_time:trip_date_time,
					  exp_time:exp_time,
					  customer_msg:customer_msg
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'Booking Request by '+customer_name+' from '+from+' to '+to,
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendRequestApprovalByDriverEmail(toEmail,first_name,driver_name,from,to,trip_date_time){
		try {
			readHTMLFile(__dirname +'/template/RequestApprovalByDriverEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  driver_name:driver_name,
					  from:from,
					  to:to,
					  trip_date_time:trip_date_time 
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'Confirmed! It’s time to pack your stuff',
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	// done
	sendRequestDeclinedByDriverEmail(toEmail,first_name,driver_name,from,to,trip_date_time,declinedResone){
		try {
			readHTMLFile(__dirname +'/template/RequestDeclinedByDriverEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  driver_name:driver_name,
					  from:from,
					  to:to,
					  trip_date_time:trip_date_time,
					  declinedResone:declinedResone			 
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'Trip request declined by '+driver_name,
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//done
	sendRequestCancelledByPassengerEmail(toEmail,first_name,seat,driver_name,from,to,trip_date_time,cancelledResone){
		try {
			readHTMLFile(__dirname +'/template/RequestCancelledByPassengerEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  driver_name:driver_name,
					  from:from,
					  to:to,
					  trip_date_time:trip_date_time,
					  cancelledResone:cancelledResone,
					  seat:seat				 
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: first_name+' cancelled booking with you from '+from+' to '+to,
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	// api pending
	sendReviewTripByPassengerEmail(toEmail,first_name,from,to){
		try {
			readHTMLFile(__dirname +'/template/ReviewTripByPassengerEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  from:from,
					  to:to 
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'How was your trip? ',
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	// api pending
	sendReviewTripByDriverEmail(toEmail,first_name,from,to){
		try {
			readHTMLFile(__dirname +'/template/ReviewTripByDriverEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name,
					  from:from,
					  to:to 
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'How was your trip? ',
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	},
	//admin side
	sendIdVerificationEmail(toEmail,first_name){
		try {
			readHTMLFile(__dirname +'/template/IdVerificationEmailTemplate.html', function(err, html) {
				if (err) {
					console.log('error reading file', err);
					return;
				 }
				 var template = handlebars.compile(html);
				 var replacements = {
					  first_name:first_name
				 };
				 var htmlToSend = template(replacements);
				const token=123;
				var mailOptions = {
					to: toEmail,
					from: 'noreply@humbleride.ca',
					subject: 'Your ID is verified',
					html : htmlToSend
				};
				transport.sendMail(mailOptions, function(err, info) {
					if (err) {
						console.log(err)
					} else {
						// return emailResponse;
						console.log(info);
					}
				});
				return;
			});
			
		} catch (err) {
			console.log(err);
		}
	}


}; 