module.exports = {
  validatemobilenumber: function (inputNumber) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (inputNumber.match(phoneno)) {
      return true;
    } else {
      // console.log("message");
      return false;
    }
  },
  removeDuplicates: function (arrToBeFiltered, keyToMatch) {
    let dups = {};
    return arrToBeFiltered.filter(function (item) {
      if (item[keyToMatch] in dups) {
        return false;
      } else {
        dups[item[keyToMatch]] = true;
        return true;
      }
    });
  },
  sendsms: async function (messagebody, to) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const client = require("twilio")(accountSid, authToken);
    try {
      const smsres = await client.messages
        .create({
          body: messagebody,
          from: "+15017122661",
          to: to,
        })
        .then((message) => console.log(message.sid));
      return true;
    } catch (err) {
      console.log(err);
    }
  },
};
