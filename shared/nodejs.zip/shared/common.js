module.exports = {
  validatemobilenumber: function (inputNumber) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (inputNumber.match(phoneno)) {
      return true;
    } else {
      // console.log("message");
      return false;
    }
  },
  removeDuplicates: function (arrToBeFiltered, keyToMatch) {
    let dups = {};
    return arrToBeFiltered.filter(function (item) {
      if (item[keyToMatch] in dups) {
        return false;
      } else {
        dups[item[keyToMatch]] = true;
        return true;
      }
    });
  },
  sendsms: async function (messagebody, to) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const client = require("twilio")(accountSid, authToken);
    try {
      const smsres = await client.messages
        .create({
          body: messagebody,
          from: "+15017122661",
          to: to,
        })
        .then((message) => console.log(message.sid));
      return true;
    } catch (err) {
      console.log(err);
    }
  },
  sendNotification: async function (
    text,
    title,
    notification_id,
    payload = null
  ) {
    const OneSignal = require("onesignal-node"); // One signal library
    // One signal client setup with appId and API Key
    const client = new OneSignal.Client(
      "94d98edd-ee71-477d-858b-f23545df72a3",
      "ZGQwZGQzYWEtOTkyNi00ZmQzLWJlNmYtNmZkZTJmZjk4YzMz"
    );  
    var notification = {
      contents: {
        en: text,
      },
      headings: {
        en: title,
      },
      include_player_ids: notification_id,
    };
    if (payload !== null) {
      notification.data = payload;
    }

    // using async/await
    try {
      const response = await client.createNotification(notification);
      return { status: true, content: response };
    } catch (e) {
      return { status: false, content: e };
    }
  },
  sendNotificationBulk: async function (
    text,
    title,
    notification_ids,
    payload = null
  ) {
    const OneSignal = require("onesignal-node"); // One signal library
    // One signal client setup with appId and API Key
    const client = new OneSignal.Client(
      "94d98edd-ee71-477d-858b-f23545df72a3",
      "ZGQwZGQzYWEtOTkyNi00ZmQzLWJlNmYtNmZkZTJmZjk4YzMz"
    );  
    var notification = {
      contents: {
        en: text,
      },
      headings: {
        en: title,
      },
      include_player_ids: notification_ids,
    };
    if (payload !== null) {
      notification.data = payload;
    }

    // using async/await
    try {
      const response = await client.createNotification(notification);
      return { status: true, content: response };
    } catch (e) {
      return { status: false, content: e };
    }
  },
};
